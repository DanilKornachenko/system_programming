#include <stdio.h>
#include "my_lib.h"

void print_hello_message()
{
  printf("Моя группа: %s, моя фамилия %s.\n", "9ИС-490К", "Корначенко");
}
